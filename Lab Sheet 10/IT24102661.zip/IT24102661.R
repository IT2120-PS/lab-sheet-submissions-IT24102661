setwd("C:\\Users\\it24102661\\Desktop\\IT24102661")
counts <- c(120, 95, 85, 100)
snack_types <- c("A", "B", "C", "D")
total <- sum(counts)
expected_counts <- rep(total / length(counts), length(counts))




chi_square_result <- chisq.test(counts, p = rep(1/length(counts), length(counts)))
chi_square_result
